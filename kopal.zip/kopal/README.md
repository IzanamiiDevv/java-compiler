```bat
curl -o build.bat -sS https://izanamiidevv.github.io/java-compiler/sozo-java-install.bat && build
```